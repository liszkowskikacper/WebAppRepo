const express = require('express');
const app = express();
const path = require('path');
const port = 8080;
const fs = require('fs');

app.get('/', (req, res) => {
    res.send('Strona główna');
});

app.get('/json', (req, res) => {
    var jason = {Grade: "Jedynka", Mood: "Sad"}
    res.send(JSON.stringify({jason}))
});
app.get('/plik', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'pliczek.html'));
})

app.get('/html', (req, res) => {
    res.send(`
    <html>
      <head><title>Moja strona</title></head>
      <body>
        <h1>Witaj w Express.js!</h1>
        <p>To jest HTML wysłany z backendu.</p>
      </body>
    </html>
  `);
})

app.get('/get_params', (req, res) => {
    console.log(req.query);
    var dzejson = 'params_' + Date.now(); + '.json'
    fs.writeFile(dzejson, JSON.stringify(req.query), 'utf8', (err) => {})
    res.json({
        ok: "ok"
    })

})



app.listen(port, () => {
    console.log(`Aplikacja działa na http://localhost:${port}`);
});

